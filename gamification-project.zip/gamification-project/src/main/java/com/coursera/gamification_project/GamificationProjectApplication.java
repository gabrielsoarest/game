package com.coursera.gamification_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GamificationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GamificationProjectApplication.class, args);
	}

}
