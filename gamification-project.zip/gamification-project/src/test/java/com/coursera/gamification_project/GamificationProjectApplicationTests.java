package com.coursera.gamification_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamificationProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
