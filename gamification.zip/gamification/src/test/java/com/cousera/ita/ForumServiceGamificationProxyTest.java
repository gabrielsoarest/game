package com.cousera.ita;

import br.com.cousera.ita.achieviement.Achievement;
import br.com.cousera.ita.achieviement.Badge;
import br.com.cousera.ita.achieviement.Points;
import br.com.cousera.ita.achieviement.service.ForumService;
import br.com.cousera.ita.achieviement.service.impl.CreationPointsObserver;
import br.com.cousera.ita.achieviement.service.impl.ForumServiceGamificationProxy;
import br.com.cousera.ita.achieviement.service.impl.MemoryAchievementStorage;
import br.com.cousera.ita.achieviement.service.impl.ParticipationPointsObserver;
import br.com.cousera.ita.achieviement.storage.AchievementStorageFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ForumServiceGamificationProxyTest {

    private ForumService realForumServiceMock;
    private ForumServiceGamificationProxy proxy;
    private MemoryAchievementStorage storage;

    @BeforeEach
    public void setUp() {
        realForumServiceMock = Mockito.mock(ForumService.class);
        storage = new MemoryAchievementStorage();
        AchievementStorageFactory.setAchievementStorage(storage);
        proxy = new ForumServiceGamificationProxy(realForumServiceMock);
    }

    @Test
    void testAddTopicAddsCorrectAchievements() {
        proxy.addTopic("user1", "topic1");
        verify(realForumServiceMock, times(1)).addTopic("user1", "topic1");

        List<Achievement> achievements = storage.getAchievements("user1");
        assertNotNull(achievements);
        assertEquals(2, achievements.size());

        List<String> achievementNames = achievements.stream().map(Achievement::getName).toList();
        assertTrue(achievementNames.contains("CREATION"));
        assertTrue(achievementNames.contains("I CAN TALK"));

        Points creationPoints = (Points) storage.getAchievement("user1", "CREATION");
        assertNotNull(creationPoints);
        assertEquals(5, creationPoints.getValue());

        Badge iCanTalkBadge = (Badge) storage.getAchievement("user1", "I CAN TALK");
        assertNotNull(iCanTalkBadge);
    }

    @Test
    void testAddCommentAddsCorrectAchievements() {
        proxy.addComment("user2", "topic1", "comment1");
        verify(realForumServiceMock, times(1)).addComment("user2", "topic1", "comment1");

        List<Achievement> achievements = storage.getAchievements("user2");
        assertNotNull(achievements);
        assertEquals(2, achievements.size());

        List<String> achievementNames = achievements.stream().map(Achievement::getName).collect(Collectors.toList());
        assertTrue(achievementNames.contains("PARTICIPATION"));
        assertTrue(achievementNames.contains("LET ME ADD"));

        Points participationPoints = (Points) storage.getAchievement("user2", "PARTICIPATION");
        assertNotNull(participationPoints);
        assertEquals(3, participationPoints.getValue());

        Badge letMeAddBadge = (Badge) storage.getAchievement("user2", "LET ME ADD");
        assertNotNull(letMeAddBadge);
    }

    @Test
    void testLikeTopicAddsCorrectAchievements() {
        proxy.likeTopic("user3", "topic1", "topicUser");
        verify(realForumServiceMock, times(1)).likeTopic("user3", "topic1", "topicUser");

        Points creationPoints = (Points) storage.getAchievement("topicUser", "CREATION");
        assertNotNull(creationPoints);
        assertEquals(1, creationPoints.getValue());
    }

    @Test
    void testLikeCommentAddsCorrectAchievements() {
        proxy.likeComment("user4", "topic1", "comment1", "commentUser");
        verify(realForumServiceMock, times(1)).likeComment("user4", "topic1", "comment1", "commentUser");

        Points participationPoints = (Points) storage.getAchievement("commentUser", "PARTICIPATION");
        assertNotNull(participationPoints);
        assertEquals(1, participationPoints.getValue());
    }

    @Test
    void testAddTopicTwiceSumsPointsAndAddsBadgeOnce() {
        proxy.addTopic("user5", "topic1");
        proxy.addTopic("user5", "topic2");

        Points creationPoints = (Points) storage.getAchievement("user5", "CREATION");
        assertNotNull(creationPoints);
        assertEquals(10, creationPoints.getValue());

        Badge iCanTalkBadge = (Badge) storage.getAchievement("user5", "I CAN TALK");
        assertNotNull(iCanTalkBadge);

        List<Achievement> achievements = storage.getAchievements("user5");
        assertEquals(2, achievements.size()); // Apenas os dois achievements esperados
    }

    @Test
    void testMultipleActionsYieldsExpectedResults() {
        proxy.addTopic("user6", "topic1"); // 5 CREATION, I CAN TALK
        proxy.addComment("user6", "topic1", "comment1"); // 3 PARTICIPATION, LET ME ADD
        proxy.likeTopic("user7", "topic2", "user6"); // 1 CREATION
        proxy.likeComment("user8", "topic3", "comment2", "user6"); // 1 PARTICIPATION

        Points creationPoints = (Points) storage.getAchievement("user6", "CREATION");
        assertNotNull(creationPoints);
        assertEquals(6, creationPoints.getValue()); // 5 + 1

        Points participationPoints = (Points) storage.getAchievement("user6", "PARTICIPATION");
        assertNotNull(participationPoints);
        assertEquals(4, participationPoints.getValue()); // 3 + 1

        assertNotNull(storage.getAchievement("user6", "I CAN TALK"));
        assertNotNull(storage.getAchievement("user6", "LET ME ADD"));
        assertEquals(4, storage.getAchievements("user6").size());
    }

    @Test
    void testExceptionPreventsAchievementAddition() {
        doThrow(new RuntimeException("Simulated error")).when(realForumServiceMock).addTopic("user9", "topic1");

        assertThrows(RuntimeException.class, () -> proxy.addTopic("user9", "topic1"));

        List<Achievement> achievements = storage.getAchievements("user9");
        assertTrue(achievements.isEmpty());
    }

    @Test
    void testCreationPointsObserverAwardsBadge() {
        storage.addObserver(new CreationPointsObserver(storage));

        // 5 * 20 = 100
        for (int i = 0; i < 20; i++) {
            proxy.addTopic("user10", "topic" + i);
        }

        Points creationPoints = (Points) storage.getAchievement("user10", "CREATION");
        assertEquals(100, creationPoints.getValue());

        Badge inventorBadge = (Badge) storage.getAchievement("user10", "INVENTOR");
        assertNotNull(inventorBadge);
    }

    @Test
    void testParticipationPointsObserverAwardsBadge() {
        storage.addObserver(new ParticipationPointsObserver(storage));

        // 3 * 33 + 1 = 100
        for (int i = 0; i < 33; i++) {
            proxy.addComment("user11", "topic" + i, "comment" + i);
        }

        // Adiciona 1 ponto para atingir 100
        proxy.likeComment("user12", "topic1", "comment1", "user11");


        Points participationPoints = (Points) storage.getAchievement("user11", "PARTICIPATION");
        assertEquals(100, participationPoints.getValue());

        Badge communityBadge = (Badge) storage.getAchievement("user11", "PART OF THE COMMUNITY");
        assertNotNull(communityBadge);
    }
}
