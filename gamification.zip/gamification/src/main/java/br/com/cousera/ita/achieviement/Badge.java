package br.com.cousera.ita.achieviement;

public class Badge extends Achievement {
    public Badge(String name) {
        super(name);
    }

    @Override
    public void update(Achievement newAchievement) {

    }
}
