package br.com.cousera.ita.achieviement.service;

import br.com.cousera.ita.achieviement.Achievement;

public interface AchievementObserver {

    void achievementUpdate(String user, Achievement a);
}
