package br.com.cousera.ita.achieviement.service.impl;

import br.com.cousera.ita.achieviement.Badge;
import br.com.cousera.ita.achieviement.Points;
import br.com.cousera.ita.achieviement.service.AchievementStorage;
import br.com.cousera.ita.achieviement.service.ForumService;
import br.com.cousera.ita.achieviement.storage.AchievementStorageFactory;

public class ForumServiceGamificationProxy implements ForumService {
    private final ForumService realService;
    private final AchievementStorage storage;

    public ForumServiceGamificationProxy(ForumService realService) {
        this.realService = realService;
        this.storage = AchievementStorageFactory.getAchievementStorage();
    }

    @Override
    public void addTopic(String user, String topic) {
        realService.addTopic(user, topic);
        storage.addAchievement(user, new Points("CREATION", 5));
        storage.addAchievement(user, new Badge("I CAN TALK"));
    }

    @Override
    public void addComment(String user, String topic, String comment) {
        realService.addComment(user, topic, comment);
        storage.addAchievement(user, new Points("PARTICIPATION", 3));
        storage.addAchievement(user, new Badge("LET ME ADD"));
    }

    @Override
    public void likeTopic(String user, String topic, String topicUser) {
        realService.likeTopic(user, topic, topicUser);
        storage.addAchievement(topicUser, new Points("CREATION", 1));
    }

    @Override
    public void likeComment(String user, String topic, String comment, String commentUser) {
        realService.likeComment(user, topic, comment, commentUser);
        storage.addAchievement(commentUser, new Points("PARTICIPATION", 1));
    }
}
