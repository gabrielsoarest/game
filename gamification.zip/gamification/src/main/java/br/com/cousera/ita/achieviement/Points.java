package br.com.cousera.ita.achieviement;

public class Points extends Achievement {

    private int value;

    public Points(String name, int value) {
        super(name);
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    public void update(Achievement newAchievement) {
        if (newAchievement instanceof Points) {
            Points newPoints = (Points) newAchievement;
            this.value += newPoints.getValue();
        }
    }
}
