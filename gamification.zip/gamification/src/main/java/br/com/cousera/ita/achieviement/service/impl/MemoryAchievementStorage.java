package br.com.cousera.ita.achieviement.service.impl;

import br.com.cousera.ita.achieviement.Achievement;
import br.com.cousera.ita.achieviement.service.AchievementObserver;
import br.com.cousera.ita.achieviement.service.AchievementStorage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemoryAchievementStorage  implements AchievementStorage {
    private final Map<String, List<Achievement>> userAchievements = new HashMap<>();
    private final List<AchievementObserver> observers = new ArrayList<>();

    @Override
    public void addAchievement(String user, Achievement a) {
        List<Achievement> achievements = userAchievements.computeIfAbsent(user, k -> new ArrayList<>());

        Achievement existing = getAchievement(user, a.getName());
        if (existing != null) {
            existing.update(a);
        } else {
            achievements.add(a);
            existing = a;
        }

        notifyObservers(user, existing);
    }

    @Override
    public List<Achievement> getAchievements(String user) {
        return userAchievements.getOrDefault(user, new ArrayList<>());
    }

    @Override
    public Achievement getAchievement(String user, String achievementName) {
        for (Achievement achievement : getAchievements(user)) {
            if (achievement.getName().equals(achievementName)) {
                return achievement;
            }
        }
        return null;
    }

    @Override
    public void addObserver(AchievementObserver observer) {
        observers.add(observer);
    }

    private void notifyObservers(String user, Achievement achievement) {
        for (AchievementObserver observer : observers) {
            observer.achievementUpdate(user, achievement);
        }
    }
}
