package br.com.cousera.ita.achieviement.service.impl;

import br.com.cousera.ita.achieviement.Achievement;
import br.com.cousera.ita.achieviement.Badge;
import br.com.cousera.ita.achieviement.Points;
import br.com.cousera.ita.achieviement.service.AchievementObserver;
import br.com.cousera.ita.achieviement.service.AchievementStorage;

public class CreationPointsObserver implements AchievementObserver {
    private final AchievementStorage storage;

    public CreationPointsObserver(AchievementStorage storage) {
        this.storage = storage;
    }

    @Override
    public void achievementUpdate(String user, Achievement a) {
        if (a instanceof Points && "CREATION".equals(a.getName())) {
            Points points = (Points) a;
            if (points.getValue() >= 100) {
                storage.addAchievement(user, new Badge("INVENTOR"));
            }
        }
    }
}
