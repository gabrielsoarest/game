package br.com.cousera.ita.achieviement.storage;

import br.com.cousera.ita.achieviement.service.AchievementStorage;
import br.com.cousera.ita.achieviement.service.impl.MemoryAchievementStorage;

public class AchievementStorageFactory {

    private static AchievementStorage achievementStorage;

    public static AchievementStorage getAchievementStorage() {
        if (achievementStorage == null) {
            achievementStorage = new MemoryAchievementStorage();
        }
        return achievementStorage;
    }

    public static void setAchievementStorage(AchievementStorage storage) {
        achievementStorage = storage;
    }
}
